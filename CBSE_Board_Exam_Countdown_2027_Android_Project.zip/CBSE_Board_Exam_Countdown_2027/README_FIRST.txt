CBSE BOARD EXAM COUNTDOWN 2027 — ANDROID APP SOURCE

This project creates a standalone Android app. The countdown runs offline and targets
17 February 2027 at 00:00 India Standard Time.

IMPORTANT:
This ZIP is the Android Studio project source, NOT a compiled APK. A compiled APK
cannot be produced in this workspace because the Android SDK/build toolchain is not
installed. Follow either method below to build the APK.

METHOD A — GitHub Actions (no Android Studio needed):
1. Create/sign in to a GitHub account.
2. Create a NEW repository, e.g. cbse-countdown-2027.
3. Upload the CONTENTS of this ZIP to the repository (not the ZIP itself).
4. Ensure the default branch is named "main".
5. Open the repository's Actions tab and enable workflows if asked.
6. Open "Build Android APK" and click "Run workflow" (or push a commit).
7. When the run completes, open it and download the artifact:
   CBSE-Board-Exam-Countdown-2027-APK
8. Extract the downloaded artifact. It contains app-debug.apk.
9. Send app-debug.apk to students/parents via WhatsApp or another file-sharing method.
10. On Android, recipients download the APK, tap it, allow installation from that
    source if Android asks, and install.

METHOD B — Android Studio:
1. Open this folder in Android Studio.
2. Let Gradle sync; install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK at app/build/outputs/apk/debug/app-debug.apk.

DISTRIBUTION NOTES:
- This is a debug-signed APK suitable for direct testing/distribution to your group.
- Android may show an "unknown app" installation warning; users should install only
  if they trust the sender and verify the file came from your school.
- To publish on Google Play, a release build and Play Console process are required.
- No web hosting is needed. The app contains its countdown page locally.
- Countdown reaches zero at the start of 17 February 2027 (IST).
